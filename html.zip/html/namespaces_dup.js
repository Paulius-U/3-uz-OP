var namespaces_dup =
[
    [ "Catch", "namespace_catch.html", "namespace_catch" ],
    [ "mpl_", "namespacempl__.html", null ]
];
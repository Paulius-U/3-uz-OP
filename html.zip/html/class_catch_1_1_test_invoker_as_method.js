var class_catch_1_1_test_invoker_as_method =
[
    [ "TestInvokerAsMethod", "class_catch_1_1_test_invoker_as_method.html#a119c4bdbbdd95c42859c18541987a1a4", null ],
    [ "invoke", "class_catch_1_1_test_invoker_as_method.html#a8115a06efe273f4112ec0b5452c1b5f2", null ]
];
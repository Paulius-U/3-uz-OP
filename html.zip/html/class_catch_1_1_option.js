var class_catch_1_1_option =
[
    [ "Option", "class_catch_1_1_option.html#a8efb01b593d798decc80cbbdf311f2a3", null ],
    [ "Option", "class_catch_1_1_option.html#a5aeb9c22d48a6882bdf5fb4730b06c86", null ],
    [ "Option", "class_catch_1_1_option.html#af02f2e4559f06384baec0def8c68c5fd", null ],
    [ "~Option", "class_catch_1_1_option.html#a37fe90bb47bb909f150a5ad6be25581a", null ],
    [ "none", "class_catch_1_1_option.html#a821753afdc3fac947a13a01fbe0d248e", null ],
    [ "operator bool", "class_catch_1_1_option.html#aba0def0bd9cd45d4e00fe47a604b0270", null ],
    [ "operator!", "class_catch_1_1_option.html#a96dccb86bdf45ee0c08e122b6133bef3", null ],
    [ "operator*", "class_catch_1_1_option.html#afd989852fa453731c3190dac63caccb0", null ],
    [ "operator*", "class_catch_1_1_option.html#a734fc9c2eb1a1f7f8e8f6a4eb12160f0", null ],
    [ "operator->", "class_catch_1_1_option.html#acad340798a16c8f700f8763119e90f31", null ],
    [ "operator->", "class_catch_1_1_option.html#ae8343cbc36dbb95b2dce333d2a6fdc28", null ],
    [ "operator=", "class_catch_1_1_option.html#a78c65b15dd6b2fbd04c5012c43017c8f", null ],
    [ "operator=", "class_catch_1_1_option.html#a2be7e343ab22d6061726d32ab4622653", null ],
    [ "reset", "class_catch_1_1_option.html#a37b4e0e5d4d56296adacd267a616f4e0", null ],
    [ "some", "class_catch_1_1_option.html#a97c95829afbe92f2bcc5fd75b32c0825", null ],
    [ "valueOr", "class_catch_1_1_option.html#a8d9ae2e30b0eb76fe134a6fbc8423124", null ]
];
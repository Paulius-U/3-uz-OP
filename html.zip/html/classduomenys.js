var classduomenys =
[
    [ "duomenys", "classduomenys.html#af00acbedd054d362a0ea7d2af231b806", null ],
    [ "~duomenys", "classduomenys.html#a312c1fcccbcaea0499e4b86eb9ebd162", null ],
    [ "duomenys", "classduomenys.html#aa522adf3393fa2b33adb398611353771", null ],
    [ "get_Pavarde", "classduomenys.html#a1748eead84137b138b6a31ba63385f56", null ],
    [ "get_Vardas", "classduomenys.html#a1d66058743a477b7dadb4c85157fd3eb", null ],
    [ "get_Vidurkio_Balas", "classduomenys.html#ae82c4c9b3a4ac61ef4cb050ec20d7d48", null ],
    [ "operator=", "classduomenys.html#ab16937808aa4fdddb64d806328eca58a", null ],
    [ "set_Pavarde", "classduomenys.html#a367efaed29f3576c4bada5856a49b106", null ],
    [ "set_Vardas", "classduomenys.html#aa5cfc311a205d81a0a53fedbb33a3fa0", null ],
    [ "set_Vidurkio_Balas", "classduomenys.html#ab4a86d45c90ca7c1edba749739b0551a", null ]
];
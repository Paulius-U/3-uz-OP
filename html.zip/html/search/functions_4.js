var searchData=
[
  ['emplaceunscopedmessage_1004',['emplaceUnscopedMessage',['../struct_catch_1_1_i_result_capture.html#a49f74f1323ef8be71b8f9b8e8b2c0fc2',1,'Catch::IResultCapture']]],
  ['empty_1005',['empty',['../struct_catch_1_1_source_line_info.html#a10a5b5b7dff82971879c2eb8d83f9b3b',1,'Catch::SourceLineInfo::empty()'],['../class_catch_1_1_string_ref.html#a0b4841c28cbb14ba07296964a0187023',1,'Catch::StringRef::empty() const noexcept -&gt; bool']]],
  ['end_1006',['end',['../class_catch_1_1_string_ref.html#a3ce9afc711b559d6cc59666898fc0828',1,'Catch::StringRef']]],
  ['endswith_1007',['endsWith',['../namespace_catch.html#ada025504f627feaf9ac68ca391515dff',1,'Catch::endsWith(std::string const &amp;s, std::string const &amp;suffix)'],['../namespace_catch.html#afd801a3e33fd7a8b91ded0d02747a93f',1,'Catch::endsWith(std::string const &amp;s, char suffix)']]],
  ['endswith_1008',['EndsWith',['../namespace_catch_1_1_matchers.html#ae5a45efb4538c57c43e04f3f9043ad6e',1,'Catch::Matchers']]],
  ['endswithmatcher_1009',['EndsWithMatcher',['../struct_catch_1_1_matchers_1_1_std_string_1_1_ends_with_matcher.html#aa5ec700b4629562f74f362080accfd7b',1,'Catch::Matchers::StdString::EndsWithMatcher']]],
  ['epsilon_1010',['epsilon',['../class_catch_1_1_detail_1_1_approx.html#acd26adba86a066b9f40dad467f23bc85',1,'Catch::Detail::Approx::epsilon()'],['../struct_catch_1_1_matchers_1_1_vector_1_1_approx_matcher.html#a31c47dac5f7346b526a145da343f9e3e',1,'Catch::Matchers::Vector::ApproxMatcher::epsilon()']]],
  ['equals_1011',['Equals',['../namespace_catch_1_1_matchers.html#af8af7dfc338335ed4c788cb1b37fc59f',1,'Catch::Matchers::Equals(std::string const &amp;str, CaseSensitive::Choice caseSensitivity=CaseSensitive::Yes)'],['../namespace_catch_1_1_matchers.html#a3ab7fff821bc655bd4875cc1aa745101',1,'Catch::Matchers::Equals(std::vector&lt; T, AllocComp &gt; const &amp;comparator)']]],
  ['equalsmatcher_1012',['EqualsMatcher',['../struct_catch_1_1_matchers_1_1_std_string_1_1_equals_matcher.html#ab740f1fb2310e9fe3fed5134d4c7e4c8',1,'Catch::Matchers::StdString::EqualsMatcher::EqualsMatcher()'],['../struct_catch_1_1_matchers_1_1_vector_1_1_equals_matcher.html#aca4855dbe43977f4aceae8fd0a0422a8',1,'Catch::Matchers::Vector::EqualsMatcher::EqualsMatcher()']]],
  ['exceptionearlyreported_1013',['exceptionEarlyReported',['../struct_catch_1_1_i_result_capture.html#ae63ecec95db4c236c63ecf616f483810',1,'Catch::IResultCapture']]],
  ['exceptionmessagematcher_1014',['ExceptionMessageMatcher',['../class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher.html#ace55942f39ba653db3fd69d6d90e188f',1,'Catch::Matchers::Exception::ExceptionMessageMatcher']]],
  ['exceptiontranslatorregistrar_1015',['ExceptionTranslatorRegistrar',['../class_catch_1_1_exception_translator_registrar.html#aa73229de911f26b1df6c6c87c4d9e04e',1,'Catch::ExceptionTranslatorRegistrar']]],
  ['expectedtofail_1016',['expectedToFail',['../struct_catch_1_1_test_case_info.html#abe33d81233230cdae8afa714688e905b',1,'Catch::TestCaseInfo']]],
  ['exprlhs_1017',['ExprLhs',['../class_catch_1_1_expr_lhs.html#ad22c6af1a7d6993240624d299714a479',1,'Catch::ExprLhs']]]
];

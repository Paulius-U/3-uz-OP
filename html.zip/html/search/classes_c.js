var searchData=
[
  ['pluralise_861',['pluralise',['../struct_catch_1_1pluralise.html',1,'Catch']]],
  ['predicatematcher_862',['PredicateMatcher',['../class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html',1,'Catch::Matchers::Generic']]]
];

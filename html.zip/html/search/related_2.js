var searchData=
[
  ['getcurrentmutablecontext_1410',['getCurrentMutableContext',['../struct_catch_1_1_i_mutable_context.html#aea4b25692aaf4397cdf630716976f6b8',1,'Catch::IMutableContext']]]
];

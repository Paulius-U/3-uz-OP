var searchData=
[
  ['nameandtags_858',['NameAndTags',['../struct_catch_1_1_name_and_tags.html',1,'Catch']]],
  ['noncopyable_859',['NonCopyable',['../class_catch_1_1_non_copyable.html',1,'Catch']]]
];

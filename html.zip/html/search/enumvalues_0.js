var searchData=
[
  ['always_1368',['Always',['../struct_catch_1_1_show_durations.html#a82fa0174554187220c1eda175f122ee1ab49682ccb55f2d6b4dfcdb027c09da9a',1,'Catch::ShowDurations']]],
  ['auto_1369',['Auto',['../struct_catch_1_1_use_colour.html#a6aa78da0c2de7539bb9e3757e204a3f1a5c7fa9f5f5536187e8f47df35b892bb7',1,'Catch::UseColour']]]
];

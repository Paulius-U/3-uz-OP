var class_catch_1_1_string_ref =
[
    [ "const_iterator", "class_catch_1_1_string_ref.html#ac3aa3d16f48b5429a480f823c504f93c", null ],
    [ "size_type", "class_catch_1_1_string_ref.html#a06b4db8fc82b197004291cf370b2ba7c", null ],
    [ "StringRef", "class_catch_1_1_string_ref.html#a611907867225695d38198c058758c92d", null ],
    [ "StringRef", "class_catch_1_1_string_ref.html#aea45f5089c53adac362bff6bd7c40943", null ],
    [ "StringRef", "class_catch_1_1_string_ref.html#a36df94807491c0ad84184fb8e44e1a7c", null ],
    [ "StringRef", "class_catch_1_1_string_ref.html#a7fe41469048f906e9a847798cd335f23", null ],
    [ "begin", "class_catch_1_1_string_ref.html#ab0adc7198d60867c2842b998ae456795", null ],
    [ "c_str", "class_catch_1_1_string_ref.html#a1669cb2765e820ca258159676cbd82a5", null ],
    [ "data", "class_catch_1_1_string_ref.html#ab0f85edde9f97153fc758fac3bb14507", null ],
    [ "empty", "class_catch_1_1_string_ref.html#a0b4841c28cbb14ba07296964a0187023", null ],
    [ "end", "class_catch_1_1_string_ref.html#a3ce9afc711b559d6cc59666898fc0828", null ],
    [ "isNullTerminated", "class_catch_1_1_string_ref.html#a646e58f5f4e1f5e82cfba06d9fd5d016", null ],
    [ "operator std::string", "class_catch_1_1_string_ref.html#ad9fde21785affacc32d7da7a70d74e93", null ],
    [ "operator!=", "class_catch_1_1_string_ref.html#aaa6c8bf61c4628034c19763d1c8ad215", null ],
    [ "operator==", "class_catch_1_1_string_ref.html#aabb30149ab961187e4b3ff3394bf6e73", null ],
    [ "operator[]", "class_catch_1_1_string_ref.html#a4ba2e01eec1f0f56c257d213c796ab3b", null ],
    [ "size", "class_catch_1_1_string_ref.html#acb22719801de2b64361b4c283080d4e5", null ],
    [ "substr", "class_catch_1_1_string_ref.html#a594bc3e10ffad77df92f7d1a4c99d7ff", null ]
];
var class_catch_1_1_detail_1_1_approx =
[
    [ "Approx", "class_catch_1_1_detail_1_1_approx.html#a1a8618ea8db08c66bd3d9fe8f74b957a", null ],
    [ "Approx", "class_catch_1_1_detail_1_1_approx.html#ab14b979fa8a37f21d037157fabed4072", null ],
    [ "epsilon", "class_catch_1_1_detail_1_1_approx.html#acd26adba86a066b9f40dad467f23bc85", null ],
    [ "margin", "class_catch_1_1_detail_1_1_approx.html#a6467dc18791e1a1f4c15c4fb63cf5051", null ],
    [ "operator()", "class_catch_1_1_detail_1_1_approx.html#ad8b2757f4804f9a1d3fa674efb98c20e", null ],
    [ "operator-", "class_catch_1_1_detail_1_1_approx.html#aa9adf5f05e641df770039543d5067d30", null ],
    [ "scale", "class_catch_1_1_detail_1_1_approx.html#a8f4d2def2920a3840d3271f6d9c5ede2", null ],
    [ "toString", "class_catch_1_1_detail_1_1_approx.html#a972fd9ac60607483263f1b0f0f9955e6", null ],
    [ "operator!=", "class_catch_1_1_detail_1_1_approx.html#a31d62e3c35abb86cf25e02601966ca5d", null ],
    [ "operator!=", "class_catch_1_1_detail_1_1_approx.html#a29696f14ebd51887c8c88e771d12ef54", null ],
    [ "operator<=", "class_catch_1_1_detail_1_1_approx.html#a6040b908588745570847d7ae8483b091", null ],
    [ "operator<=", "class_catch_1_1_detail_1_1_approx.html#a0369de03e81bc2ceaf6c9d830476bd49", null ],
    [ "operator==", "class_catch_1_1_detail_1_1_approx.html#a0e5ef1957d4c38d7857005909c613743", null ],
    [ "operator==", "class_catch_1_1_detail_1_1_approx.html#ab38782a37d09b527ca5e126dbf433dda", null ],
    [ "operator>=", "class_catch_1_1_detail_1_1_approx.html#a5899b8a36725406701e2ebded2971ee6", null ],
    [ "operator>=", "class_catch_1_1_detail_1_1_approx.html#affd27efc62be386daeecb7a09e828d44", null ]
];
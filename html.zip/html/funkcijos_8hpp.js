var funkcijos_8hpp =
[
    [ "asmuo", "classasmuo.html", "classasmuo" ],
    [ "duomenys", "classduomenys.html", "classduomenys" ],
    [ "Dalinimas_Vector", "funkcijos_8hpp.html#a4efbf5f5c28e3d8d229ec52868c7574d", null ],
    [ "Data_Vector", "funkcijos_8hpp.html#a128641024a0551c0c768f7cb5d2f58f8", null ],
    [ "Failo_Skaitymas_Vector", "funkcijos_8hpp.html#a0652c41a94acb9070b32dc348e7ced70", null ],
    [ "Galutinis_Vector", "funkcijos_8hpp.html#abfb3c8777007a89f7ebc0ba1dcaf42af", null ],
    [ "Klaida", "funkcijos_8hpp.html#a76c1d0923260388c9b30ef0d84ada11e", null ],
    [ "Mediana_Vector", "funkcijos_8hpp.html#a3e87262bea2b2c4064f9ac0093792fe7", null ],
    [ "Pasirinkimas", "funkcijos_8hpp.html#ac0ccb7dd685ee3f846c80b574f634b44", null ],
    [ "Pasirinkimas", "funkcijos_8hpp.html#a13b8b8a76de14d8dcc49180f772d40c9", null ],
    [ "Pazymiai", "funkcijos_8hpp.html#a97ef2792a0e5639c9e3d3520802a9352", null ],
    [ "Pazymiu_generavimas_Vector", "funkcijos_8hpp.html#a664cc3f19c31a229b92e01643a5e23eb", null ],
    [ "Spauzdinimas_Vector", "funkcijos_8hpp.html#a57b268b4a7ca580bca3aed14b40e09fa", null ],
    [ "Vectorius", "funkcijos_8hpp.html#a00816790d7266a23544a4f324b87b3c2", null ],
    [ "Vidurkis_Vector", "funkcijos_8hpp.html#ae23f7ba7a317efbfd3dd8dbaff418734", null ]
];
var namespace_catch_1_1detail =
[
    [ "void_type", "struct_catch_1_1detail_1_1void__type.html", "struct_catch_1_1detail_1_1void__type" ],
    [ "is_range_impl", "struct_catch_1_1detail_1_1is__range__impl.html", null ],
    [ "is_range_impl< T, typename void_type< decltype(begin(std::declval< T >()))>::type >", "struct_catch_1_1detail_1_1is__range__impl_3_01_t_00_01typename_01void__type_3_01decltype_07begin8604ecb9de16ea7789f2f694ac896ffd.html", null ]
];
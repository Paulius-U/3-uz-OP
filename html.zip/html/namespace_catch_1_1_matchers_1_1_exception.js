var namespace_catch_1_1_matchers_1_1_exception =
[
    [ "ExceptionMessageMatcher", "class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher.html", "class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher" ]
];
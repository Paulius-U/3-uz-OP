var classasmuo =
[
    [ "asmuo", "classasmuo.html#a3bb461b8ca6dfdad409b8907dec65f38", null ],
    [ "asmuo", "classasmuo.html#a8b965296a2f1f2bdeff5a6311970d7e6", null ],
    [ "~asmuo", "classasmuo.html#ae5bafc0066d742aa6f8fbdad14927f3c", null ],
    [ "get_Pavarde", "classasmuo.html#a3b5c597e96ab1076989b3e52069f188c", null ],
    [ "get_Vardas", "classasmuo.html#a74af394768c823853db198b9334b04b1", null ],
    [ "set_Pavarde", "classasmuo.html#a77f963110963e053352c7173f6c5f677", null ],
    [ "set_Vardas", "classasmuo.html#a097569094051ddc2725f4ba1a44481c4", null ],
    [ "Pavarde", "classasmuo.html#a39cdbb525561857abe9e0f5e271b4b8d", null ],
    [ "Vardas", "classasmuo.html#a42fba88596222776aaf18c8424c42d74", null ]
];
var failas_8cpp =
[
    [ "GetFile", "failas_8cpp.html#abd63d5a0d05c2ed7f26557d1c4f1c548", null ],
    [ "Sukurimas", "failas_8cpp.html#a92ef5da2250361b9e751d688d50f2bbd", null ]
];
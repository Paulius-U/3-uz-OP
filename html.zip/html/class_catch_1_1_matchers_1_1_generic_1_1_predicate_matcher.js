var class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher =
[
    [ "PredicateMatcher", "class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html#a57d53ef028c2f7b92b016f627f91aa76", null ],
    [ "describe", "class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html#af7d59e94892cc09471bbaefac4c889fd", null ],
    [ "match", "class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html#a2ec0e8ec19c4c5e26271d59a06a62b52", null ]
];
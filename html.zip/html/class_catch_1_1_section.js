var class_catch_1_1_section =
[
    [ "Section", "class_catch_1_1_section.html#a68fd4e51e8981aaa7ddb00d8a6abd099", null ],
    [ "~Section", "class_catch_1_1_section.html#aa1422edd68a77aa578b5cc6b8b69f86f", null ],
    [ "operator bool", "class_catch_1_1_section.html#a0632b804dcea1417a2970620a9742eb3", null ]
];
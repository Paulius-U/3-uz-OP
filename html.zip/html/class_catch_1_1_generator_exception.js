var class_catch_1_1_generator_exception =
[
    [ "GeneratorException", "class_catch_1_1_generator_exception.html#a3cf9282d555ec32389665ce723bf36ea", null ],
    [ "what", "class_catch_1_1_generator_exception.html#ade029163144d136f12187e5b9a0161d5", null ]
];
var class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher =
[
    [ "ExceptionMessageMatcher", "class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher.html#ace55942f39ba653db3fd69d6d90e188f", null ],
    [ "describe", "class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher.html#a3543441985ec877a781e660a403b1bae", null ],
    [ "match", "class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher.html#aa0566d24990d69e96495360b8f79593d", null ]
];
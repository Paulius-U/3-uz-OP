var class_catch_1_1_non_copyable =
[
    [ "NonCopyable", "class_catch_1_1_non_copyable.html#a4b492dd5753f9952350fb64dc6cb9fe2", null ],
    [ "~NonCopyable", "class_catch_1_1_non_copyable.html#a81254677280fef337eb4a676e91e3293", null ]
];
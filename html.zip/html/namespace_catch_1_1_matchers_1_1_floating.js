var namespace_catch_1_1_matchers_1_1_floating =
[
    [ "WithinAbsMatcher", "struct_catch_1_1_matchers_1_1_floating_1_1_within_abs_matcher.html", "struct_catch_1_1_matchers_1_1_floating_1_1_within_abs_matcher" ],
    [ "WithinUlpsMatcher", "struct_catch_1_1_matchers_1_1_floating_1_1_within_ulps_matcher.html", "struct_catch_1_1_matchers_1_1_floating_1_1_within_ulps_matcher" ],
    [ "WithinRelMatcher", "struct_catch_1_1_matchers_1_1_floating_1_1_within_rel_matcher.html", "struct_catch_1_1_matchers_1_1_floating_1_1_within_rel_matcher" ]
];
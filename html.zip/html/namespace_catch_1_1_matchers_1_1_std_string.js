var namespace_catch_1_1_matchers_1_1_std_string =
[
    [ "CasedString", "struct_catch_1_1_matchers_1_1_std_string_1_1_cased_string.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_cased_string" ],
    [ "StringMatcherBase", "struct_catch_1_1_matchers_1_1_std_string_1_1_string_matcher_base.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_string_matcher_base" ],
    [ "EqualsMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_equals_matcher.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_equals_matcher" ],
    [ "ContainsMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_contains_matcher.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_contains_matcher" ],
    [ "StartsWithMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_starts_with_matcher.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_starts_with_matcher" ],
    [ "EndsWithMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_ends_with_matcher.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_ends_with_matcher" ],
    [ "RegexMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_regex_matcher.html", "struct_catch_1_1_matchers_1_1_std_string_1_1_regex_matcher" ]
];
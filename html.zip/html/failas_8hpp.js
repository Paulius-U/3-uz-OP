var failas_8hpp =
[
    [ "GetFile", "failas_8hpp.html#abd63d5a0d05c2ed7f26557d1c4f1c548", null ],
    [ "Sukurimas", "failas_8hpp.html#a728308a4698da3fa42c91687f2ffa260", null ]
];
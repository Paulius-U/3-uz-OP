var class_catch_1_1_match_expr =
[
    [ "MatchExpr", "class_catch_1_1_match_expr.html#ae55ee9bf46c8676c65e9df291a98c345", null ],
    [ "streamReconstructedExpression", "class_catch_1_1_match_expr.html#ad3e41adb597750b2219bb37e51185629", null ]
];
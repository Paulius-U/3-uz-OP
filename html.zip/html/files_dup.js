var files_dup =
[
    [ "catch.hpp", "catch_8hpp.html", "catch_8hpp" ],
    [ "failas.cpp", "failas_8cpp.html", "failas_8cpp" ],
    [ "failas.hpp", "failas_8hpp.html", "failas_8hpp" ],
    [ "funkcijos.cpp", "funkcijos_8cpp.html", "funkcijos_8cpp" ],
    [ "funkcijos.hpp", "funkcijos_8hpp.html", "funkcijos_8hpp" ],
    [ "Main.cpp", "_main_8cpp.html", "_main_8cpp" ],
    [ "tempCodeRunnerFile.cpp", "temp_code_runner_file_8cpp.html", null ],
    [ "testMate.cpp", "test_mate_8cpp.html", "test_mate_8cpp" ]
];